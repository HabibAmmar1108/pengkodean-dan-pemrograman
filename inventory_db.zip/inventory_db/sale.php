<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Penjualan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Buat Penjualan</h1>
    <form method="POST" action="">
        <label>Pilih Barang:</label>
        <select name="id_barang" required>
            <?php
            include 'config.php';
            $sql = "SELECT id_barang, nama_barang FROM barang";
            $result = $conn->query($sql);
            while ($row = $result->fetch_assoc()) {
                echo "<option value='{$row['id_barang']}'>{$row['nama_barang']}</option>";
            }
            ?>
        </select><br>
        <label>Jumlah:</label><input type="number" name="jumlah" required><br>
        <input type="submit" value="Tambah ke Penjualan">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id_barang = $_POST['id_barang'];
        $jumlah = $_POST['jumlah'];

        $sql = "SELECT harga_jual, (SELECT jumlah FROM stok WHERE id_barang = $id_barang) as stok 
                FROM barang WHERE id_barang = $id_barang";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();

        if ($row['stok'] >= $jumlah) {
            $subtotal = $row['harga_jual'] * $jumlah;
            $sql_sale = "INSERT INTO penjualan (total_harga) VALUES ($subtotal)";
            $conn->query($sql_sale);
            $id_penjualan = $conn->insert_id;

            $sql_detail = "INSERT INTO detail_penjualan (id_penjualan, id_barang, jumlah, harga_satuan, subtotal) 
                           VALUES ($id_penjualan, $id_barang, $jumlah, {$row['harga_jual']}, $subtotal)";
            $conn->query($sql_detail);

            $sql_update = "UPDATE stok SET jumlah = jumlah - $jumlah WHERE id_barang = $id_barang";
            $conn->query($sql_update);

            echo "Penjualan berhasil!";
        } else {
            echo "Stok tidak cukup!";
        }
        $conn->close();
    }
    ?>
</body>
</html>