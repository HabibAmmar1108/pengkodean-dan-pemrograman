// Bisa ditambahkan untuk validasi form di sisi klien
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', function(e) {
        let inputs = form.querySelectorAll('input[required], select[required]');
        inputs.forEach(input => {
            if (!input.value) {
                e.preventDefault();
                alert('Harap isi semua field!');
            }
        });
    });
});
// Inisialisasi DataTables
$(document).ready(function() {
    $('#barangTable').DataTable({
        "paging": true,
        "searching": true,
        "ordering": true,
        "info": true
    });
});

// Filter Kategori (opsional, jika DataTables tidak digunakan)
document.getElementById('categoryFilter').addEventListener('change', function() {
    let filter = this.value.toLowerCase();
    let rows = document.querySelectorAll('tbody tr');
    rows.forEach(row => {
        let category = row.cells[2].textContent.toLowerCase();
        row.style.display = filter === '' || category === filter ? '' : 'none';
    });
});