<?php
// Aktifkan error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'config.php';

// Periksa apakah ID ada
if (!isset($_GET['id'])) {
    die("<script>
        Swal.fire({
            icon: 'error',
            title: 'Gagal!',
            text: 'ID barang tidak ditemukan!',
            showConfirmButton: true
        }).then(() => {
            window.location.href = 'index.php';
        });
    </script>");
}

$id_barang = (int)$_GET['id'];

// Gunakan prepared statement untuk keamanan
$stmt = $conn->prepare("SELECT jumlah FROM stok WHERE id_barang = ?");
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}
$stmt->bind_param("i", $id_barang);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $jumlah = $row['jumlah'];
} else {
    $jumlah = 0; // Jika tidak ada stok, anggap 0
}

if ($jumlah == 0) {
    // Mulai transaksi
    $conn->begin_transaction();

    try {
        // Hapus dari detail_penjualan
        $stmt = $conn->prepare("DELETE FROM detail_penjualan WHERE id_barang = ?");
        if (!$stmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        $stmt->bind_param("i", $id_barang);
        $stmt->execute();

        // Hapus dari stok
        $stmt = $conn->prepare("DELETE FROM stok WHERE id_barang = ?");
        if (!$stmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        $stmt->bind_param("i", $id_barang);
        $stmt->execute();

        // Hapus dari barang
        $stmt = $conn->prepare("DELETE FROM barang WHERE id_barang = ?");
        if (!$stmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        $stmt->bind_param("i", $id_barang);
        if (!$stmt->execute()) {
            throw new Exception("Execute failed: " . $conn->error);
        }

        // Commit transaksi
        $conn->commit();

        // Redirect dengan JavaScript
        echo "<script>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: 'Barang berhasil dihapus!',
                showConfirmButton: false,
                timer: 1500
            }).then(() => {
                window.location.href = 'index.php';
            });
        </script>";
    } catch (Exception $e) {
        // Rollback transaksi jika gagal
        $conn->rollback();
        echo "<script>
            Swal.fire({
                icon: 'error',
                title: 'Gagal!',
                text: '" . addslashes($e->getMessage()) . "',
                showConfirmButton: true
            }).then(() => {
                window.location.href = 'index.php';
            });
        </script>";
    }
} else {
    echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Gagal!',
            text: 'Barang tidak bisa dihapus karena stok masih ada!',
            showConfirmButton: true
        }).then(() => {
            window.location.href = 'index.php';
        });
    </script>";
}

$stmt->close();
$conn->close();
?>