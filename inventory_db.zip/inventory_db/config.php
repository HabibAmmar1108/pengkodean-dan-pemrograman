<?php
$host = "localhost";
$username = "root"; // Default phpMyAdmin username
$password = "";     // Default kosong
$dbname = "inventory_db";

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>