<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tambah Barang</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Tambah Barang Baru</h1>
    <form method="POST" action="">
        <label>Nama Barang:</label><input type="text" name="nama_barang" required><br>
        <label>Kategori:</label>
        <select name="id_kategori" required>
            <?php
            include 'config.php';
            $sql = "SELECT * FROM kategori";
            $result = $conn->query($sql);
            while ($row = $result->fetch_assoc()) {
                echo "<option value='{$row['id_kategori']}'>{$row['nama_kategori']}</option>";
            }
            ?>
        </select><br>
        <label>Supplier:</label>
        <select name="id_supplier" required>
            <?php
            $sql = "SELECT * FROM supplier";
            $result = $conn->query($sql);
            while ($row = $result->fetch_assoc()) {
                echo "<option value='{$row['id_supplier']}'>{$row['nama_supplier']}</option>";
            }
            ?>
        </select><br>
        <label>Harga Beli:</label><input type="number" name="harga_beli" step="0.01" required><br>
        <label>Harga Jual:</label><input type="number" name="harga_jual" step="0.01" required><br>
        <label>Jumlah Stok:</label><input type="number" name="jumlah" required><br>
        <input type="submit" value="Simpan">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nama_barang = $_POST['nama_barang'];
        $id_kategori = $_POST['id_kategori'];
        $id_supplier = $_POST['id_supplier'];
        $harga_beli = $_POST['harga_beli'];
        $harga_jual = $_POST['harga_jual'];
        $jumlah = $_POST['jumlah'];

        $sql = "INSERT INTO barang (nama_barang, id_kategori, id_supplier, harga_beli, harga_jual) 
                VALUES ('$nama_barang', $id_kategori, $id_supplier, $harga_beli, $harga_jual)";
        if ($conn->query($sql) === TRUE) {
            $id_barang = $conn->insert_id;
            $sql_stok = "INSERT INTO stok (id_barang, jumlah) VALUES ($id_barang, $jumlah)";
            $conn->query($sql_stok);
            echo "Barang berhasil ditambahkan!";
        } else {
            echo "Error: " . $conn->error;
        }
        $conn->close();
    }
    ?>
</body>
</html>