<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sistem Persediaan</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;600;700&display=swap" rel="stylesheet">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <!-- Font Awesome untuk ikon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="logo-nav">
            <img src="images/logo.jpg" alt="Logo Harley Rebel" class="logo">
        </div>
        <div class="nav-links">
            <a href="index.php">Daftar Barang</a>
            <a href="add_item.php">Tambah Barang</a>
            <a href="sale.php">Buat Penjualan</a>
        </div>
    </nav>

    <div class="container">
        <h1>Daftar Barang</h1>

        <!-- Form Pencarian -->
        <div class="search-bar">
            <input type="text" id="searchInput" placeholder="Cari barang...">
        </div>

        <!-- Filter Kategori -->
        <div class="filter-bar">
            <select id="categoryFilter">
                <option value="">Semua Kategori</option>
                <?php
                include 'config.php';
                $sql = "SELECT * FROM kategori";
                $result = $conn->query($sql);
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='{$row['nama_kategori']}'>{$row['nama_kategori']}</option>";
                }
                ?>
            </select>
        </div>

        <!-- Tabel -->
        <table id="barangTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama Barang</th>
                    <th>Kategori</th>
                    <th>Stok</th>
                    <th>Harga Jual</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT b.id_barang, b.nama_barang, k.nama_kategori, s.jumlah, b.harga_jual 
                        FROM barang b 
                        LEFT JOIN kategori k ON b.id_kategori = k.id_kategori 
                        LEFT JOIN stok s ON b.id_barang = s.id_barang";
                $result = $conn->query($sql);
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                        <td>{$row['id_barang']}</td>
                        <td>{$row['nama_barang']}</td>
                        <td>{$row['nama_kategori']}</td>
                        <td>{$row['jumlah']}</td>
                        <td>{$row['harga_jual']}</td>
                        <td>";
                    if ($row['jumlah'] == 0) {
                        echo "<a href='delete_item.php?id={$row['id_barang']}' class='delete-btn' onclick='return confirm(\"Yakin ingin menghapus {$row['nama_barang']}?\")'><i class='fas fa-trash-alt'></i></a>";
                    } else {
                        echo "-";
                    }
                    echo "</td>
                    </tr>";
                }
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>

    <!-- Library JavaScript -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="script.js"></script>
</body>
</html>